package us.codecraft.webmagic.pipeline;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import us.codecraft.webmagic.utils.ConUtil;

public class procedure {
	
	ConUtil db = new ConUtil();	
	
	public String getAutoNo(String tableName, int maxRecord) throws SQLException{
			
		Connection con = db.getCon();		
	    CallableStatement cstmt = null;
	    String autoNo = null;
	    
	    try{
	    	/*调用存储过程*/
	        cstmt = con.prepareCall("{call auto_no_for_table_proc(?, ?, ?)}");
	        /*为第一个输入参数赋值*/
	        cstmt.setString(1, tableName);
	        /*为第二个输入参数赋值*/
	        cstmt.setInt(2, maxRecord);
	        /*设置第三个输出参数的类型*/
	        cstmt.registerOutParameter(3, java.sql.Types.CHAR);
	        cstmt.execute();
	        autoNo = cstmt.getString(3);
            
        }catch(Exception e){
            System.out.println("getAutoNo: "+e);
            
        }finally{
            cstmt.close();
            con.close();
        }
	    
        return autoNo;
	}
	
	/*得到表中主码最大记录的主码编号后8位存储过程*/
	public String getTableMaxNumber(String tableName) throws SQLException{
		
		Connection con = db.getCon();
	    CallableStatement cstmt = null;
	    String maxNumber = null;

	    try{
	    	/*调用存储过程*/
	        cstmt = con.prepareCall("{call get_table_max_number_proc(?, ?)}");
	        /*为第一个输入参数赋值*/
	        cstmt.setString(1, tableName);
	        /*设置第二个输出参数的类型*/
	        cstmt.registerOutParameter(2, java.sql.Types.CHAR);
	        cstmt.execute();
	        /*得到第二个输出参数*/
	        maxNumber = cstmt.getString(2);
            
        }catch(Exception e){
            System.out.println("getTableMaxNumber: "+e);
            
        }finally{
            cstmt.close();
            con.close();
        }

        return maxNumber;
	}

	/*根据表属性名得到相应主码编号*/
	public String getPriKeyOfTable(String tableName, String tableAttribute) throws SQLException{
		
		Connection con = db.getCon();		
	    CallableStatement cstmt = null;
	    String priKey = null;
	    
	    try{
	    	/*调用存储过程*/
	        cstmt = con.prepareCall("{call get_primary_key_of_table_proc(?, ?, ?)}");
	        /*为第一个输入参数赋值*/
	        cstmt.setString(1, tableName);
	        /*为第二个输入参数赋值*/
	        cstmt.setString(2, tableAttribute);
	        /*设置第三个输出参数的类型*/
	        cstmt.registerOutParameter(3, java.sql.Types.CHAR);
	        cstmt.execute();
	        /*得到第三个输出参数*/
	        priKey = cstmt.getString(3);
            
        }catch(Exception e){
            System.out.println("getPriKeyOfTable: "+e);
            
        }finally{
            cstmt.close();
            con.close();
        }

        return priKey;
	}
}
