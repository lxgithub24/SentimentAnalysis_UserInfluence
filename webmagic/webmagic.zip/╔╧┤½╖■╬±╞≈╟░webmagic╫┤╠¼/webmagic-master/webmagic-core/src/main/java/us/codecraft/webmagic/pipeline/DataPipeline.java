/*package us.codecraft.webmagic.pipeline;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import us.codecraft.webmagic.ResultItems;
import us.codecraft.webmagic.SpiderModel;
import us.codecraft.webmagic.Task;
import us.codecraft.webmagic.utils.ConUtil;

public class DataPipeline implements Pipeline {

	@Override
	public void process(ResultItems resultItems, Task task) {
		// TODO Auto-generated method stub

		ConUtil db = new ConUtil();

		Connection con = db.getCon();

		String sql = "insert into spider (title,content,date) values(?,?,?)";

		try {
			PreparedStatement ps = con.prepareStatement(sql);

			SpiderModel sm = new SpiderModel();
			int count = 0;
			for (Map.Entry<String, Object> entry : resultItems.getAll()
					.entrySet()) {
				if (entry.getKey().equals("title")) {

					List<String> l = (List<String>) entry.getValue();
					for (String s : l)
						count++;

				}
			}

			for (Map.Entry<String, Object> entry : resultItems.getAll()
					.entrySet()) {

				if (entry.getKey().equals("title")) {
					for (int j = 0; j < count; j++) {
						List<String> l = (List<String>) entry.getValue();
						int i = 0;
						for (String s : l) {
							sm.setTitle(s.toString());
							if (i == j) {

								for (Map.Entry<String, Object> entr : resultItems
										.getAll().entrySet()) {
									if (entr.getKey().equals("content")) {

										sm.setContent(entr.getValue()
												.toString());
									}
									if (entr.getKey().equals("date")) {

										sm.setDate(entr.getValue().toString());
									}
								}
								break;
							} else
								i++;
						}
						
						ps.setString(1, sm.getTitle());
						ps.setString(2, sm.getContent());
						ps.setString(3, sm.getDate());
						ps.executeUpdate();
					}
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}*/


/*package us.codecraft.webmagic.pipeline;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import us.codecraft.webmagic.ResultItems;
import us.codecraft.webmagic.SpiderModel;
import us.codecraft.webmagic.Task;
import us.codecraft.webmagic.utils.ConUtil;

public class DataPipeline implements Pipeline{

	@Override
	public void process(ResultItems resultItems, Task task) {
		// TODO Auto-generated method stub
		
		ConUtil db = new ConUtil();
		
		Connection con = db.getCon();
		
		String sql = "insert into spider (title,content,date) values(?,?,?)";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			
			SpiderModel sm = new SpiderModel();
			
			for(Map.Entry<String,Object> entry : resultItems.getAll().entrySet()){
				
				if(entry.getKey().equals("title")){
					sm.setTitle(entry.getValue().toString());
				}				
				else if(entry.getKey().equals("content")){
					
					sm.setContent(entry.getValue().toString());
				}else{
					
					sm.setDate(entry.getValue().toString());
				}
				
				ps.setString(1, sm.getTitle());
				
				ps.setString(2, sm.getContent());
				
				ps.setString(3, sm.getDate());
							
			}
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
}
*/
 
 package us.codecraft.webmagic.pipeline;//米胖,mipang

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import us.codecraft.webmagic.ResultItems;
import us.codecraft.webmagic.SpiderModel;
import us.codecraft.webmagic.Task;
import us.codecraft.webmagic.utils.ConUtil;

public class DataPipeline implements Pipeline{

//DTProvince 五个表为：DTCity ,DTScenic , DTTheme ,DTScenicPhoto ,DTScenicToTheme ,
	@Override
	public void process(ResultItems resultItems, Task task) throws SQLException{
		// TODO Auto-generated method stub
		
		/*String[] tableNames = {"DTCity", "DTScenic", "DTScenicPhoto", 
				"DTScenicToTheme", "DTTheme"};
		String[] autoNos = {};   // 存储自动产生的编号
		int[] maxRecord = {};    // 存储特定表中最大的记录编号后8位
*/		
		ConUtil db = new ConUtil();
		Connection con = db.getCon();
		
		procedure pro = new procedure();
		// 每个表分别调用存储过程以产生对应的编号
		/*for( int i=0; i<tableNames.length; i++){
			
			 * 注意：是否每个表都需要产生编号？
			 * 一个市有很多景区，每次插入数据景区表可能每次都需要产生编号，而该市已经存在，所以这点需要考虑;
			 * 同理，一个主题下也有多个景区，主题信息也不能重复插入
			 * 
			// 得到表中的最大记录编号后8位
			String maxNum =	pro.getTableMaxNumber(tableNames[i]);
			if ( maxNum.equals("表名输入错误") ){
				System.out.println("表名输入错误");
				// 结束程序运行
				System.exit(0);
			}
			else{
				// 将类型为字符串的后8位转换为int
				maxRecord[i] = Integer.parseInt(maxNum);
				// 自动产生编号
				autoNos[i] = pro.getAutoNo(tableNames[i], maxRecord[i]);
			}			
		}	*/
		
	/*
	 * begin
	 * 
	 * 以下代码为插入数据代码
	 * 由于某些表之间存在外键约束，因此向表中插入数据需要按顺序插入，否则容易引起外键约束错误
	 * 1.先插入市信息 2.插入景区信息 3.插入主题信息 4.插入景区图片信息 5.插入景区所属的主题信息
	 * 
	 * */	
		String cityNo = null;
		// 根据省份名字得到省份编号(因为插入市信息需要得到省份编号)
		String provinceNo = pro.getPriKeyOfTable("DTProvince", "湖南");
		// 可以向市信息表中插入数据
		
		String sql0 = "insert into DTCity (cityNo, provinceNo, cityName) values(?,?,?)";
		//后续执行代码略...
		
		try {
			PreparedStatement ps = con.prepareStatement(sql0);
		//	System.out.println(ps);
		//	System.out.println(ps == null);
			SpiderModel sm = new SpiderModel();
			boolean isCityName = false;
			boolean isTableDTCity = false;
			boolean flag_DTCity = false;
			for(Map.Entry<String,Object> entry : resultItems.getAll().entrySet()){
				
				if(entry.getKey().equals("cityName")){
					if(pro.getPriKeyOfTable("DTCity", entry.getValue().toString())==null){//如果数据表空或者对应的no不存在
						isCityName = true;
						isTableDTCity = true;
						sm.setCityNo( pro.getAutoNo("DTCity", Integer.parseInt(pro.getTableMaxNumber("DTCity"))));
						sm.setCityName(entry.getValue().toString());
						
					}
					
				}if(entry.getKey().equals("provinceName")){
					if(pro.getPriKeyOfTable("DTProvince", entry.getValue().toString())!=null){
						flag_DTCity = true;
					sm.setProvinceNo(pro.getPriKeyOfTable("DTProvince", entry.getValue().toString()) );
					isCityName=false;
				}}
				if(isTableDTCity&&flag_DTCity){
						ps.setString(1, sm.getCityNo());
						ps.setString(2, sm.getProvinceNo());
						ps.setString(3, sm.getCityName());
					}
				
				
				cityNo = sm.getCityNo();
			}
			if(isTableDTCity&&flag_DTCity){
				ps.executeUpdate();
				isTableDTCity = false;
				flag_DTCity = false;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//sql1 = "insert into DTScenic (cityNo) select cityNo from DTCity";
		// 插入景区信息(需要用到自动产生的景区编号、市编号)

		String scenicNo = null;
		boolean isTableDTScenic = false;
		/*String sql1 = "insert into DTScenic (scenicNo,scenicName,cityNo,scenicIntroduction,nationalRate,isHotScenic) values(?,?,?,?,?,?)";
		//后续执行代码略...
		
		try {
			PreparedStatement ps = con.prepareStatement(sql1);
			
			SpiderModel sm = new SpiderModel();
			
			for(Map.Entry<String,Object> entry : resultItems.getAll().entrySet()){
								
				if(entry.getKey().equals("scenicName")){
					if(pro.getPriKeyOfTable("DTScenic", entry.getValue().toString()).isEmpty()||ps == null){
						isTableDTScenic = true;
						sm.setScenicNo(pro.getAutoNo("DTScenic",  Integer.parseInt(pro.getTableMaxNumber("DTScenic")) ));
						sm.setScenicName(entry.getValue().toString());
					}
				}
				if(entry.getKey().equals("cityName")){
					sm.setCityNo(pro.getPriKeyOfTable("DTCity", entry.getValue().toString()));
				}
				
				if(entry.getKey().equals("scenicIntroduction")){
						sm.setScenicIntroduction(entry.getValue().toString());
				}				
				if(entry.getKey().equals("nationalRate")){
					
					sm.setNationalRate(entry.getValue().toString());
				}				
				if(entry.getKey().equals("isHotScenic")){
					
					sm.setIsHotScenic(entry.getValue().toString());
				}
				if(isTableDTScenic == true){
					ps.setString(1, sm.getScenicNo());
					ps.setString(2, sm.getScenicName());
					ps.setString(3, sm.getCityNo());
					ps.setString(4, sm.getScenicIntroduction());
					ps.setString(5, sm.getNationalRate());
					ps.setBoolean(6, false);
					scenicNo = sm.getScenicNo();
				}
				
				System.out.println(sm.getScenicNo());
				System.out.println(sm.getScenicName());
				System.out.println(sm.getCityNo());
				System.out.println(sm.getScenicIntroduction());
				//System.out.println(sm.getScenicIntroduction());
				
			}
			if(isTableDTScenic == true){
				ps.executeUpdate();
				isTableDTScenic = false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		String ThemeNo = null;
		// 插入主题信息
			/*String sql2 = "insert into DTTheme (ThemeNo, ThemeName) values(?,?)";
	// 插入景区图片信息
		try {
			PreparedStatement ps = con.prepareStatement(sql2);
			
			SpiderModel sm = new SpiderModel();
			
			int count_DTTheme = 0;
			for (Map.Entry<String, Object> entry : resultItems.getAll()
					.entrySet()) {
				if (entry.getKey().equals("ThemeName")) {

					List<String> l = (List<String>) entry.getValue();
					for (String s : l)
						count_DTTheme++;

				}
			}
			
			boolean isDTTheme = false;
			for(Map.Entry<String,Object> entry : resultItems.getAll().entrySet()){
						
				if(entry.getKey().equals("ThemeName")){
					
					
						//for(int i=0;i<count_DTTheme;i++){
							List<String> l = (List<String>) entry.getValue();
							for(String s:l){
								if ( pro.getPriKeyOfTable("DTTheme", s.toString() ).isEmpty()||ps == null){
								sm.setThemeNo(pro.getAutoNo("DTTheme", Integer.parseInt(pro.getTableMaxNumber("DTTheme"))));
								sm.setThemeName(s.toString());
								
								ps.setString(1, sm.getThemeNo());
								ps.setString(2, sm.getThemeName());
								ThemeNo = sm.getThemeNo();
								isDTTheme = true;
								ps.executeUpdate();
							}
						}
						
					//}
				}
			}
			if ( isDTTheme){
				ps.executeUpdate();
				isDTTheme = false;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		//String recordNo = null;
		/*String sql3 = "insert into DTScenicPhoto (recordNo, scenicNo, photoPath) values(?,?,?)";
	//	后续执行代码略...
		boolean isDTScenicPhoto = false;
		try {
			PreparedStatement ps = con.prepareStatement(sql3);
			
			SpiderModel sm = new SpiderModel();
			
			for(Map.Entry<String,Object> entry : resultItems.getAll().entrySet()){
				if(entry.getKey().equals("photoPath")){
					if(pro.getPriKeyOfTable("DTScenicPhoto", entry.getValue().toString()).isEmpty()||ps == null){
					isDTScenicPhoto = true;
						sm.setRecordNo(pro.getAutoNo("DTScenicPhoto", Integer.parseInt(pro.getTableMaxNumber("DTScenicPhoto"))));
						
						sm.setPhotoPath(entry.getValue().toString());
						
						ps.setString(1, sm.getRecordNo());
						
						ps.setString(3, sm.getPhotoPath());
					}
					
				}
				if(entry.getKey().equals("scenicName")){
					sm.setScenicNo(pro.getPriKeyOfTable("DTScenic", entry.getValue().toString()) );
					ps.setString(2, sm.getScenicNo());
				}
			}
			if(isDTScenicPhoto){
				ps.executeUpdate();
				isDTScenicPhoto = false;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// 插入景区所属的主题信息
		String sql4 = "insert into DTScenicToTheme (recordNo, scenicNo, ThemeNo) values(?,?,?)";
		boolean isDTScenicToTheme = false;
		try {
			PreparedStatement ps = con.prepareStatement(sql4);
			
			SpiderModel sm = new SpiderModel();
			
			for(Map.Entry<String,Object> entry : resultItems.getAll().entrySet()){
				if(entry.getKey().equals("scenicName")){
					if(pro.getPriKeyOfTable("DTScenicToTheme", entry.getValue().toString()).isEmpty()||ps == null){
						sm.setRecordNo(pro.getAutoNo("DTScenicToTheme", Integer.parseInt(pro.getTableMaxNumber("DTScenicToTheme"))));
						ps.setString(1, sm.getRecordNo());
						isDTScenicToTheme = true;
						sm.setScenicNo(pro.getPriKeyOfTable("DTScenic", entry.getValue().toString()) );
						ps.setString(2, sm.getScenicNo());
					}
				}
				if(entry.getKey().equals("ThemeName")){
					sm.setThemeNo(pro.getPriKeyOfTable("DTTheme", entry.getValue().toString()));
					ps.setString(3, sm.getThemeNo());
				}
			}
			
			if(isDTScenicToTheme){
				ps.executeUpdate();
				isDTScenicToTheme = false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	 /** 插入数据结束
	 * end
	 * 	*/
		
		/*String sql = "insert into spider (provinceName,cityName,scenicName,scenicIntroduction,photoPath,nationalRate) values(?,?,?,?,?,?)";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			
			SpiderModel sm = new SpiderModel();
			
			for(Map.Entry<String,Object> entry : resultItems.getAll().entrySet()){
				
				if(entry.getKey().equals("provinceName")){
					sm.setProvinceName(entry.getValue().toString());
				}				
				else if(entry.getKey().equals("cityName")){
					
					sm.setCityName(entry.getValue().toString());
				}else if(entry.getKey().equals("scenicName")){
					
					sm.setScenicName(entry.getValue().toString());
				}else if(entry.getKey().equals("scenicIntroduction")){
					
					sm.setScenicIntroduction(entry.getValue().toString());
				}else if(entry.getKey().equals("photoPath")){
					
					sm.setPhotoPath(entry.getValue().toString());
				}else{
					
					sm.setNationalRate(entry.getValue().toString());
				}
				
				ps.setString(1, sm.getProvinceName());
				
				ps.setString(2, sm.getCityName());
				
				ps.setString(3, sm.getScenicName());
				
				ps.setString(4, sm.getScenicIntroduction());
				
				ps.setString(5, sm.getPhotoPath());
				
				ps.setString(6, sm.getNationalRate());
							
			}
			
			
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		
	}
	
	
}