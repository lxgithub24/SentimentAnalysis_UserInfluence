package us.codecraft.webmagic;

public class SpiderModel {
	
	private int id;
	
	private String provinceName;
	
	private String cityName;
	
	private String scenicName;
	
	private String scenicIntroduction;
	
	private String photoPath;
	
	private String nationalRate;
	
	private String cityNo;
	
	private String scenicNo;
	
	private String isHotScenic;
	
	private String ThemeNo;
	
	private String ThemeName;
	
	private String recordNo;
	
	private String provinceNo;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProvinceName() {
		return provinceName;
	}

	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getScenicName() {
		return scenicName;
	}

	public void setScenicName(String scenicName) {
		this.scenicName = scenicName;
	}
	public String getScenicIntroduction() {
		return scenicIntroduction;
	}

	public void setScenicIntroduction(String scenicIntroduction) {
		this.scenicIntroduction = scenicIntroduction;
	}
	public String getPhotoPath() {
		return photoPath;
	}

	public void setPhotoPath(String photoPath) {
		this.photoPath = photoPath;
	}
	public String getCityNo() {
		return cityNo;
	}

	public void setCityNo(String cityNo) {
		this.cityNo = cityNo;
	}
	
	public String getScenicNo() {
		return scenicNo;
	}

	public void setScenicNo(String scenicNo) {
		this.scenicNo = scenicNo;
	}
	
	public String getIsHotScenic() {
		return isHotScenic;
	}

	public void setIsHotScenic(String isHotScenic) {
		this.isHotScenic = isHotScenic;
	}
	
	public String getThemeNo() {
		return ThemeNo;
	}

	public void setThemeNo(String ThemeNo) {
		this.ThemeNo = ThemeNo;
	}
	
	public String getThemeName() {
		return ThemeName;
	}

	public void setThemeName(String ThemeName) {
		this.ThemeName = ThemeName;
	}
	
	public String getRecordNo() {
		return recordNo;
	}

	public void setRecordNo(String recordNo) {
		this.recordNo = recordNo;
	}
	
	public String getNationalRate() {
		return nationalRate;
	}

	public void setNationalRate(String nationalRate) {
		this.nationalRate = nationalRate;
	}
	
	public String getProvinceNo() {
		return provinceNo;
	}

	public void setProvinceNo(String provinceNo) {
		this.provinceNo = provinceNo;
	}
	
}
