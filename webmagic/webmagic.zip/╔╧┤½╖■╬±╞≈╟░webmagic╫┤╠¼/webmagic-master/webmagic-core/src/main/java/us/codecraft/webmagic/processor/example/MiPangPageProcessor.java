package us.codecraft.webmagic.processor.example;
import java.util.List;
import org.jsoup.Jsoup;
import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.pipeline.DataPipeline;
import us.codecraft.webmagic.pipeline.FilePipeline;
import us.codecraft.webmagic.processor.PageProcessor;
public class MiPangPageProcessor implements PageProcessor {
	public static final String URL_LIST = "^http://travel.mipang.com/sight/$|^http://\\w+.mipang.com/jingdian/$|^http://\\w+.mipang.com/jingdian/\\w+/$|^http://travel.mipang.com/sight/index-\\d+$|http://travel.mipang.com/\\d+/";//|^http://travel.mipang.com/sight/$|^http://hefei.mipang.com/jingdian/$|http://\\w+.mipang.com/jingdian/\\w+/$|^http://travel.mipang.com/sight/index-\\d+$|^http://travel.mipang.com/\\d+/$"; // 下一页
	/*public static final String URL_POST = "http://\\w+\\.mipang\\.com/jingdian/\\w+/baodian-\\d+"; // 博文*/
	/*^http://travel.mipang.com/sight/|http://\\w+\\.mipang\\.com/jingdian/|http://\\w+\\.mipang\\.com/jingdian/\\w+/$*/
	/*http://travel.mipang.com/sight/|http://hefei.mipang.com/jingdian/|http://hefei.mipang.com/jingdian/baohexiuse/*/
	/*(^http://travel.mipang.com/sight/|http://hefei.mipang.com/jingdian/baohexiuse/$)|http://hefei.mipang.com/jingdian/*/
	public static final String URL_POST = "^http://\\w+.mipang.com/jingdian/\\w+/baodian-\\d+$|^http://travel.mipang.com/bible/\\d+$";
	//|^http://travel.mipang.com/sight/index-\\d+?sort=3$";
	/*^http://\\w+\\.mipang\\.com/jingdian/\\w+/baodian-\\d+/$
	 * public static final String URL_POST = "^http://hefei.mipang.com/jingdian/baohexiuse/baodian-100615$|^http://huangshan.mipang.com/jingdian/guangmingding/baodian-100711$|^http://huangshan.mipang.com/jingdian/?sort=1$
	 * |^http://huangshan.mipang.com/jingdian/?sort=3$|^http://jinan.mipang.com/jingdian/daminghu/baodian-43028$|^http://qingdao.mipang.com/jingdian/zhanqiao/baodian-62884$";
	 * */
	private Site site = Site
			.me()
			.setSleepTime(3000)
			.setDomain("www.mipang.com")
			.setUserAgent(
					"Baiduspider+(+http://www.baidu.com/search/spider.htm)")
			.addHeader("X-DevTools-Emulate-Network-Conditions-Client-Id",
					"8DE51486-1D1A-4D2C-8877-F14AA58E422B");
	
	int count=0;
	@Override
	public void process(Page page) {// 列表页
		
		if (page.getUrl().regex(URL_LIST).match()) {
			count++;
			System.out.println("1"+"--------"+"第"+count+"次");

			page.addTargetRequests(page.getHtml()
					.links()
					.regex(URL_POST).all());
			
			page.addTargetRequests(page.getHtml()
					.links()
					.regex(URL_LIST).all());
			page.setSkip(true);
			// 文章页
			//page.addTargetRequests(page.getUrl()+"?sort=3");
		} else {
			count++;
			System.out.println("2"+"--------"+"第"+count+"次");
			
			/*page.putField(
					"cityName",
					page.getHtml().xpath("//div[@class='sight-list-sort']/allText()").all());&nbsp;*/
			//System.out.println(page.getHtml().xpath("//div[@class='place-header-box']/ul/li[4]/a/allText()").replace("旅游 ", ""));
			page.putField("cityName",page.getHtml().xpath("//*[@id='l3c-header']/div/div[1]/ul/li[5]/a[1]/allText()").replace("旅游 ", ""));
			page.putField("provinceName", page.getHtml().xpath("//*[@id='l3c-header']/div/div[1]/ul/li[4]/a[1]/allText()").replace("旅游 ", ""));
			////*[@id="l3c-header"]/div/div[1]/ul/li[4]/a[1]
			/*page.putField("scenicName",page.getHtml().xpath("//div[@style='padding-top:10px;']/h1/allText()").replace("简介", ""));
			page.putField("scenicIntroduction",page.getHtml().xpath("//div[@id='place_wiki_body']/p[2]/allText()").replace(" ", ""));page.getHtml().xpath("//div[@id='place_wiki_body']/p[2]/allText()").all());
			page.putField("photoPath", "5key");
			page.putField("nationalRate", "6");*/
			//page.putField("isHotScenic", "1");
		//	page.putField("ThemeName",page.getHtml().xpath("//*[@id='l3c-middle']/div/div[1]/div/div/h4/allText()").all());
			
		}
	}
	//*[@id="l3c-middle"]/div/div[1]/div/div/h4[1]
	@Override
	public Site getSite() {
		return site;
	}

	public static void main(String[] args) {
		Spider.create(new MiPangPageProcessor())
				.addUrl("http://travel.mipang.com/sight/")
				.addPipeline(new DataPipeline()).run();
	}
}

