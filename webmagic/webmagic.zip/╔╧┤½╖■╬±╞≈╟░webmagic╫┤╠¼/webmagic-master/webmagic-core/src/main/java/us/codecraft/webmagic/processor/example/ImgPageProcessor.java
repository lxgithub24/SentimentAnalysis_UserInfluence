package us.codecraft.webmagic.processor.example;

import org.jsoup.Jsoup;

import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.pipeline.DataPipeline;
import us.codecraft.webmagic.pipeline.FilePipeline;
import us.codecraft.webmagic.processor.PageProcessor;

public class ImgPageProcessor implements PageProcessor {
	// http://zh.wikipedia.org/wiki/%E5%8C%97%E4%BA%AC%E6%97%85%E6%B8%B8%E6%99%AF%E7%82%B9%E5%88%97%E8%A1%A8
	public static final String URL_LIST = "http://zh.wikipedia.org/wiki/%E5%8C%97%E4%BA%AC%E6%97%85%E6%B8%B8%E6%99%AF%E7%82%B9%E5%88%97%E8%A1%A8"; // 下一页
	// public static final String URL_LIST =
	// "http://blog\\.sina\\.com\\.cn/s/articlelist_1504590645_0_\\d+\\.html";
	// // 下一页
	// public static final String URL_POST =
	// "http://blog\\.sina\\.com\\.cn/s/blog_\\w+\\.html"; // 博文
	// http://zh.wikipedia.org/wiki/八达岭
	public static final String URL_POST = "http://zh\\.wikipedia\\.org/wiki/\\S+"; // 博文

	private Site site = Site.me().setDomain("zh.wikipedia.org")
			.setSleepTime(3000);

	@Override
	public void process(Page page) {
		// 列表页
		if (page.getUrl().regex(URL_LIST).match()) {
			System.out.println("1");

			page.addTargetRequests(page.getHtml()
					.xpath("//table[@class=\"wikitable\"]/tbody/tr/td").links()
					.regex(URL_POST).all());

			page.addTargetRequests(page.getHtml().xpath("//table[@class=\"wikitable\"]/tbody/tr/td").links().regex(URL_LIST).all());

			page.setSkip(true);
			// 文章页
		}else{
			System.out.println("2");
			// page.putField("date",page.getHtml().xpath("//div[@id='articlebody']/span[@class='time SG_txtc']").regex("\\((.*)\\)"));
			page.putField("date", "key");
			/*
			 * page.putField( "date", page.getHtml()
			 * .xpath("//div[@id='mw-content-text']/p/text()")
			 * .regex("\\((.*)\\)"));
			 */
			page.putField("title", page.getHtml().xpath("//h1/allText()"));
			// page.putField("title",Jsoup.parse(page.getHtml().xpath("//div[@class='articalTitle']/h2").toString()).text());

			page.putField(
					"content",
					page.getHtml().xpath(
							"//div[@id='mw-content-text']/p/allText()"));
			// page.putField("content",
			// "key");//div[@id='mw-content-text']/p/text()

		}
	}

	@Override
	public Site getSite() {
		return site;
	}

	public static void main(String[] args) {
		Spider.create(new ImgPageProcessor())
				.addUrl("http://zh.wikipedia.org/wiki/%E5%8C%97%E4%BA%AC%E6%97%85%E6%B8%B8%E6%99%AF%E7%82%B9%E5%88%97%E8%A1%A8")
				.addPipeline(new DataPipeline()).run();
	}
}
