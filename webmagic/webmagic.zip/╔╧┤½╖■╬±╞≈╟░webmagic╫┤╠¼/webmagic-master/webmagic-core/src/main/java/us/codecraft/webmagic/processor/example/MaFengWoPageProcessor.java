package us.codecraft.webmagic.processor.example;

import java.util.List;

import org.jsoup.Jsoup;

import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.pipeline.DataPipeline;
import us.codecraft.webmagic.pipeline.FilePipeline;
import us.codecraft.webmagic.processor.PageProcessor;

public class MaFengWoPageProcessor implements PageProcessor {
	// http://zh.wikipedia.org/wiki/%E5%8C%97%E4%BA%AC%E6%97%85%E6%B8%B8%E6%99%AF%E7%82%B9%E5%88%97%E8%A1%A8
	public static final String URL_LIST = "http://www.mafen1gwo.cn/mdd/"; // 下一页
	// public static final String URL_LIST =
	// http://www.mafengwo.cn/mdd/
	// "http://blog\\.sina\\.com\\.cn/s/articlelist_1504590645_0_\\d+\\.html";
	// // 下一页
	// public static final String URL_POST =
	// "http://blog\\.sina\\.com\\.cn/s/blog_\\w+\\.html"; // 博文
	// http://zh.wikipedia.org/wiki/八达岭
	public static final String URL_POST = "http://www.mafengwo.cn/mdd/"; // 博文
	private Site site = Site
			.me()
			.setSleepTime(3000)
			.setDomain("www.mafengwo.cn")
			.setUserAgent(
					"Baiduspider+(+http://www.baidu.com/search/spider.htm)")
			.addHeader("X-DevTools-Emulate-Network-Conditions-Client-Id",
					"01A8B32E-EDC9-454E-B409-597CF54CBF4E");

	@Override
	public void process(Page page) {
		// 列表页
		if (page.getUrl().regex(URL_LIST).match()) {
			System.out.println("1");

			page.addTargetRequests(page.getHtml()
					.xpath("//div[@class=\"row-list\"]").links()
					.regex(URL_POST).all());

			page.addTargetRequests(page.getHtml().links().regex(URL_LIST).all());

			// System.out.println(page.getHtml());

			// System.out.println("afnangang");

			page.setSkip(true);

			// 文章页
		} else {
			System.out.println("2");
			// System.out.println("safanhvanalnaknan");
			// page.putField("date",page.getHtml().xpath("//div[@id='articlebody']/span[@class='time SG_txtc']").regex("\\((.*)\\)"));
			page.putField("date", "dkey");
			/*
			 * page.putField( "date", page.getHtml()
			 * .xpath("//div[@id='mw-content-text']/p/text()")
			 * .regex("\\((.*)\\)"));
			 */

			/*
			 * List<String> l=page.getHtml().xpath( "//div[@class='container']"
			 * +
			 * "/div[@class='wrapper']/div[@class='row-list']/div[@class='bd bd-china']"
			 * +
			 * "/dl[@class='item']/dd/ul/li/a[@class='link-hot']/allText()").all
			 * ();
			 */

			page.putField(
					"title",
					page.getHtml()
							.xpath("//div[@class='container']/div[@class='wrapper']"
									+ "/div[@class='row-list']/div[@class='bd bd-china']/dl[@class='item']"
									+ "/dd/ul/li/a[@class='link-hot']/allText()")
							.all());
			// page.putField("title",Jsoup.parse(page.getHtml().xpath("//div[@class='articalTitle']/h2").toString()).text());
			/*page.putField("content", "key");*/
			/*page.putField("content",
					page.getHtml().xpath("//li[@class='item-large']/allText()")
							.all());*/

			// page.putField("content",
			// "key");//div[@id='mw-content-text']/p/text()

		}
	}

	@Override
	public Site getSite() {
		return site;
	}

	public static void main(String[] args) {
		Spider.create(new MaFengWoPageProcessor())
				.addUrl("http://www.mafengwo.cn/mdd/")
				.addPipeline(new DataPipeline()).run();
	}
}
