WebMagic-Worker
=====
Worker is the spider container.