webmagic-lucene
--------
尝试将webmagic与lucene结合，打造一个搜索引擎。开发中，不作为webmagic主要模块。