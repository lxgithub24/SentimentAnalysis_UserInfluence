webmagic-extension
-------
webmagic的扩展模块。包括注解格式定义爬虫、JSON、分布式等支持。